export type Outcome = 'negative' | 'positive' | 'inconclusive'
export type InspectionView = 'scene' | 'device' | 'exploded' | 'sensors' | 'airflow' | 'processing'

export const TOTAL_DURATION = 36
export const stages = [
  { title: 'Ready to begin', short: 'Ready', start: 0, end: 0, detail: 'A guided look at a proposed breath-based screening system.' },
  { title: 'Scenario started', short: 'Approach', start: 0, end: 7, detail: 'Demonstration subject approaching. Visual behavior is not a diagnostic measurement.' },
  { title: 'Preparing the device', short: 'Preparation', start: 7, end: 12, detail: 'The operator positions the removable mouthpiece. Please blow into the mouthpiece.' },
  { title: 'Collecting breath', short: 'Collection', start: 12, end: 19, detail: 'Simulated airflow moves through the mouthpiece into the collection chamber.' },
  { title: 'Sensor analysis', short: 'Sensors', start: 19, end: 27, detail: 'Proposed sensors produce illustrative signals, not real drug concentration measurements.' },
  { title: 'AI processing', short: 'Processing', start: 27, end: 36, detail: 'A scripted classification sequence processes simulated patterns. No trained model is connected.' },
  { title: 'Result available', short: 'Result', start: 36, end: 36, detail: 'A demonstration outcome, independent of the subject’s appearance or movement.' },
] as const

export const outcomes = {
  negative: { title: 'Negative', screen: 'NEGATIVE', status: 'Negative simulation', description: 'No simulated target pattern detected', followup: 'A negative simulation does not establish the absence of drug consumption.', color: '#398d75' },
  positive: { title: 'Presumptive positive', screen: 'PRESUMPTIVE\nPOSITIVE', status: 'Presumptive positive simulation', description: 'Simulated target pattern detected', followup: 'Confirmatory laboratory testing required', color: '#b27b32' },
  inconclusive: { title: 'Inconclusive', screen: 'INCONCLUSIVE', status: 'Inconclusive simulation', description: 'Simulated pattern is inconclusive', followup: 'Retest or further testing recommended', color: '#877347' },
} as const

export const sensors = [
  { id: 'BME688', role: 'VOC & environmental sensing', short: 'VOC + environment' },
  { id: 'SGP40', role: 'VOC sensing', short: 'VOC sensing' },
  { id: 'SCD41', role: 'CO₂-based breath verification', short: 'Breath verification' },
  { id: 'TCS34725', role: 'Digital colorimetric sensing', short: 'Colorimetric sensing' },
  { id: 'LMP91000', role: 'Electrochemical interface', short: 'Signal interface' },
  { id: 'ADS1115', role: 'Signal acquisition', short: 'Signal acquisition' },
  { id: 'ESP32-S3', role: 'Processing & AI inference (proposed)', short: 'Pattern processing' },
] as const

export const analysisSteps = ['Collecting simulated sensor signals', 'Conditioning the signals', 'Extracting simulated VOC patterns', 'Running simulated pattern classification', 'Preparing the demonstration result']

export function getStage(elapsed: number, started: boolean) {
  if (!started) return 0
  if (elapsed >= TOTAL_DURATION) return 6
  return stages.findIndex((stage, i) => i > 0 && elapsed >= stage.start && elapsed < stage.end)
}

export function getStageProgress(elapsed: number, stage: number) {
  if (stage === 0) return 0
  if (stage === 6) return 100
  return Math.min(100, Math.max(0, (elapsed - stages[stage].start) / (stages[stage].end - stages[stage].start) * 100))
}
