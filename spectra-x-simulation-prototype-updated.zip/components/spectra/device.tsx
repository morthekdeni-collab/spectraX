'use client'

import { useEffect, useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { Html, RoundedBox } from '@react-three/drei'
import * as THREE from 'three'
import { outcomes, sensors, type InspectionView, type Outcome } from '@/lib/simulation'

export function Solid({ position = [0, 0, 0], size, color, radius = 0.025, metalness = 0, roughness = 0.5, opacity = 1 }: { position?: [number, number, number]; size: [number, number, number]; color: string; radius?: number; metalness?: number; roughness?: number; opacity?: number }) {
  return <RoundedBox args={size} position={position} radius={radius} smoothness={3} castShadow receiveShadow><meshStandardMaterial color={color} roughness={roughness} metalness={metalness} transparent={opacity < 1} opacity={opacity} depthWrite={opacity >= 1} /></RoundedBox>
}

function Label({ position, title, subtitle }: { position: [number, number, number]; title: string; subtitle?: string }) {
  return <Html position={position} center distanceFactor={5} zIndexRange={[5, 0]}><div className="component-label"><span>{title}</span>{subtitle && <small>{subtitle}</small>}</div></Html>
}

function useScreenTexture(stage: number, outcome: Outcome) {
  const texture = useMemo(() => {
    const canvas = document.createElement('canvas')
    canvas.width = 480; canvas.height = 720
    const ctx = canvas.getContext('2d')!
    ctx.fillStyle = '#101f22'; ctx.fillRect(0, 0, 480, 720)
    ctx.textAlign = 'left'; ctx.fillStyle = '#dae9e1'; ctx.font = '600 27px sans-serif'; ctx.fillText('SPECTRA X', 36, 52)
    ctx.font = '15px monospace'; ctx.fillStyle = '#72958d'; ctx.fillText('CONCEPT PROTOTYPE', 36, 82)
    ctx.fillStyle = '#4dcaa6'; ctx.fillRect(416, 34, 27, 12)
    ctx.strokeStyle = '#2d4441'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(36, 108); ctx.lineTo(444, 108); ctx.stroke()
    ctx.textAlign = 'center'
    const isResult = stage === 6
    const color = isResult ? outcomes[outcome].color : '#70d6ba'
    ctx.strokeStyle = color; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(240, 244, 72, 0, Math.PI * 2); ctx.stroke()
    ctx.lineWidth = 3
    if (isResult && outcome === 'negative') { ctx.beginPath(); ctx.moveTo(212, 245); ctx.lineTo(235, 268); ctx.lineTo(273, 221); ctx.stroke() }
    else if (isResult) { ctx.beginPath(); ctx.moveTo(240, 205); ctx.lineTo(240, 253); ctx.stroke(); ctx.fillStyle = color; ctx.beginPath(); ctx.arc(240, 273, 4, 0, Math.PI * 2); ctx.fill() }
    else { for (let i = 0; i < 9; i++) { const h = 15 + Math.sin(i * 1.4) * 10 + (i === 4 ? 24 : 0); ctx.beginPath(); ctx.moveTo(192 + i * 12, 244 - h); ctx.lineTo(192 + i * 12, 244 + h); ctx.stroke() } }
    ctx.font = '600 30px sans-serif'; ctx.fillStyle = '#edf7f1'
    const lines = isResult ? outcomes[outcome].screen.split('\n') : [stage === 0 ? 'READY' : stage < 3 ? 'PREPARING' : stage === 3 ? 'COLLECTING' : stage === 4 ? 'SENSOR ANALYSIS' : 'PROCESSING']
    lines.forEach((line, i) => ctx.fillText(line, 240, 377 + i * 42))
    ctx.font = '19px sans-serif'; ctx.fillStyle = '#a5bbb4'; ctx.fillText(isResult ? 'Demonstration outcome' : stage === 0 ? 'Begin a new simulation' : 'Simulated signals only', 240, 458)
    ctx.fillStyle = '#193c34'; ctx.fillRect(36, 515, 408, 58); ctx.fillStyle = '#8be1c1'; ctx.font = '600 19px monospace'; ctx.fillText('SIMULATION MODE', 240, 551)
    ctx.fillStyle = '#89a49b'; ctx.font = '16px sans-serif'; ctx.fillText('NOT A MEDICAL DIAGNOSIS', 240, 628)
    ctx.font = '13px monospace'; ctx.fillText('HARDWARE NOT CONNECTED', 240, 660)
    const tex = new THREE.CanvasTexture(canvas); tex.colorSpace = THREE.SRGBColorSpace
    tex.anisotropy = 4
    return tex
  }, [stage, outcome])
  useEffect(() => () => texture.dispose(), [texture])
  return texture
}

const airflowPoints = [new THREE.Vector3(0, 0.91, 0.48), new THREE.Vector3(0, 0.79, 0.06), new THREE.Vector3(-0.2, 0.55, 0.01), new THREE.Vector3(-0.13, 0.2, 0.01), new THREE.Vector3(0.16, 0.02, 0.03), new THREE.Vector3(0.2, -0.34, 0), new THREE.Vector3(0.37, -0.5, 0)]
const airflowCurve = new THREE.CatmullRomCurve3(airflowPoints)

function Airflow({ active, paused }: { active: boolean; paused: boolean }) {
  const particles = useRef<THREE.Group>(null)
  const time = useRef(0)
  const geometry = useMemo(() => new THREE.TubeGeometry(airflowCurve, 50, 0.042, 8, false), [])
  useEffect(() => () => geometry.dispose(), [geometry])
  useFrame((_, delta) => {
    if (!paused) time.current += Math.min(delta, 0.1)
    particles.current?.children.forEach((particle, i) => { particle.position.copy(airflowCurve.getPoint((time.current * 0.25 + i / 14) % 1)) })
  })
  return <><mesh geometry={geometry}><meshPhysicalMaterial color="#66bfa9" transparent opacity={0.22} roughness={0.15} depthWrite={false} /></mesh><group ref={particles}>{Array.from({ length: 14 }, (_, i) => <mesh key={i} visible={active}><sphereGeometry args={[0.023, 8, 8]} /><meshStandardMaterial color="#71edca" emissive="#3ab88e" emissiveIntensity={1.2} /></mesh>)}</group></>
}

function Chip({ position, name, active, labels }: { position: [number, number, number]; name: string; active: boolean; labels: boolean }) {
  const ref = useRef<THREE.Group>(null)
  useFrame(({ clock }) => {
    if (!ref.current) return
    const pulse = active ? 1 + Math.sin(clock.elapsedTime * 5.5 + position[0] * 7 + position[1] * 4) * 0.055 : 1
    ref.current.scale.setScalar(pulse)
  })
  return <group ref={ref} position={position}>
    <Solid size={[0.155, 0.12, 0.047]} radius={0.008} color={name === 'SCD41' || name === 'BME688' || name === 'TCS34725' ? '#a4ada8' : '#202c2b'} metalness={0.5} />
    <mesh position={[0.048, 0.027, 0.028]}><sphereGeometry args={[0.008, 6, 6]} /><meshStandardMaterial color={active ? '#64e8b7' : '#a4b4ac'} emissive={active ? '#3bcd92' : '#000000'} emissiveIntensity={active ? 1.3 : 0.7} /></mesh>
    {[-1, 1].map((side) => Array.from({ length: 4 }, (_, i) => <mesh key={`${side}-${i}`} position={[side * 0.085, -0.04 + i * 0.026, 0]}><boxGeometry args={[0.025, 0.008, 0.017]} /><meshStandardMaterial color="#c3c1a8" metalness={0.8} roughness={0.3} /></mesh>))}
    {labels && <Label position={[position[0] < 0 ? -0.3 : 0.3, 0, 0.06]} title={name} />}
  </group>
}

export function Device({ stage, outcome, view = 'device', elapsed = 0, paused = false, labels = false }: { stage: number; outcome: Outcome; view?: InspectionView; elapsed?: number; paused?: boolean; labels?: boolean }) {
  const back = useRef<THREE.Group>(null)
  const front = useRef<THREE.Group>(null)
  const board = useRef<THREE.Group>(null)
  const battery = useRef<THREE.Group>(null)
  const pump = useRef<THREE.Group>(null)
  const inspectTime = useRef(0)
  const exploded = view === 'exploded'
  const inside = exploded || view === 'sensors' || view === 'airflow' || view === 'processing'
  const texture = useScreenTexture(stage, outcome)
  useFrame((_, delta) => {
    if (!paused) inspectTime.current += Math.min(delta, 0.05)
    if (back.current) back.current.position.lerp(new THREE.Vector3(exploded ? -1.03 : 0, 0, exploded ? -0.25 : -0.06), 0.09)
    if (front.current) front.current.position.lerp(new THREE.Vector3(exploded ? 1.16 : 0, 0, exploded ? 0.55 : 0.18), 0.09)
    if (board.current) board.current.position.lerp(new THREE.Vector3(exploded ? 0.14 : 0, 0, 0.035), 0.09)
    if (battery.current) battery.current.position.lerp(new THREE.Vector3(exploded ? -0.56 : 0, exploded ? -0.5 : -0.47, exploded ? -0.02 : -0.08), 0.09)
    if (pump.current) pump.current.position.lerp(new THREE.Vector3(exploded ? -0.56 : 0.24, exploded ? 0.12 : -0.46, 0.01), 0.09)
  })
  return <group>
    <group ref={back} position={[0, 0, -0.06]}><Solid size={[0.84, 1.67, 0.32]} color="#f0f2eb" radius={0.13} roughness={0.3} opacity={inside && !exploded ? 0.12 : 1} /><Solid position={[0, 0, 0.17]} size={[0.744, 1.55, 0.018]} color="#b6c2bb" radius={0.085} opacity={inside && !exploded ? 0.15 : 1} />{[-1, 1].map((x) => [-1, 1].map((y) => <mesh key={`${x}${y}`} position={[x * 0.33, y * 0.69, 0.188]} rotation={[Math.PI / 2, 0, 0]}><cylinderGeometry args={[0.022, 0.022, 0.012, 12]} /><meshStandardMaterial color="#8d9b94" metalness={0.8} roughness={0.3} /></mesh>))}{exploded && labels && <Label position={[-0.48, 1.05, 0]} title="01 / Outer casing" subtitle="Proposed polymer enclosure" />}</group>
    <group ref={battery} position={[0, -0.47, -0.08]} visible={inside}><Solid size={[0.38, 0.45, 0.075]} color="#596361" radius={0.02} metalness={0.4} /><Solid position={[0, 0, 0.044]} size={[0.28, 0.25, 0.006]} color="#c8cdc4" radius={0.003} />{exploded && labels && <Label position={[-0.65, -0.4, 0.12]} title="02 / Battery" subtitle="Rechargeable cell" />}</group>
    <group ref={board} position={[0, 0, 0.035]} visible={inside}>
      <Solid size={[0.65, 1.18, 0.025]} color="#22604c" radius={0.035} roughness={0.55} />
      {Array.from({ length: 10 }, (_, i) => <mesh key={i} position={[-0.28 + i * 0.059, 0, 0.019]}><boxGeometry args={[0.005, 0.92, 0.002]} /><meshStandardMaterial color="#8c9860" metalness={0.6} /></mesh>)}
      {sensors.slice(0, 6).map((sensor, i) => <Chip key={sensor.id} name={sensor.id} position={[(i % 2 === 0 ? -1 : 1) * 0.16, 0.39 - Math.floor(i / 2) * 0.22, 0.041]} active={stage >= 4 || inside} labels={labels && view === 'sensors'} />)}
      <group position={[0.09, -0.35, 0.048]}><Solid size={[0.3, 0.27, 0.06]} color="#9ea7a0" radius={0.012} metalness={0.7} roughness={0.3} /><mesh position={[0, 0.025, 0.032]}><planeGeometry args={[0.21, 0.12]} /><meshStandardMaterial color="#64786b" /></mesh>{Array.from({ length: 7 }, (_, i) => <mesh position={[-0.1 + i * 0.035, -0.12, 0.04]} key={i}><boxGeometry args={[0.014, 0.026, 0.008]} /><meshStandardMaterial color="#d1ba78" metalness={0.7} /></mesh>)}{labels && view === 'processing' && <Label position={[0.57, 0, 0.08]} title="ESP32-S3" subtitle="Proposed inference processor" />}</group>
      <Solid position={[-0.19, -0.43, 0.033]} size={[0.15, 0.07, 0.07]} color="#e1ddc4" radius={0.007} />
      {exploded && labels && <Label position={[0.2, -0.95, 0.1]} title="04 / Sensor & processing PCB" subtitle="BME688 · SGP40 · SCD41 · LMP91000 · ADS1115 · ESP32-S3" />}
      {labels && view === 'processing' && <Label position={[-0.5, -0.44, 0.06]} title="Wiring & connectors" />}
    </group>
    <group visible={inside}>
      <Solid position={[-0.1, 0.59, 0.04]} size={[0.43, 0.24, 0.17]} color="#bde6d6" radius={0.055} opacity={0.45} />
      <Solid position={[0.22, 0.53, 0.01]} size={[0.13, 0.15, 0.1]} color="#e2e8da" radius={0.015} />
      <Airflow active={inside || stage === 3} paused={paused} />
      {labels && (view === 'airflow' || exploded) && <><Label position={[-0.9, 0.6, 0.12]} title="Collection chamber" subtitle="Proposed sample pathway" /><Label position={[0.68, 0.39, 0.13]} title="Airflow sensor" /><Label position={[0.58, -0.54, 0.1]} title="Exhaust" /></>}
    </group>
    <group ref={pump} position={[0.24, -0.46, 0.01]} visible={inside}><mesh rotation={[0, 0, Math.PI / 2]} castShadow><cylinderGeometry args={[0.075, 0.075, 0.2, 18]} /><meshStandardMaterial color="#b6c2c0" metalness={0.75} roughness={0.3} /></mesh><Solid position={[0.11, 0, 0]} size={[0.05, 0.1, 0.11]} color="#253a35" radius={0.008} />{exploded && labels && <Label position={[-0.85, 0.02, 0.1]} title="03 / Miniature pump" />}</group>
    <group ref={front} position={[0, 0, 0.18]} visible={!inside || exploded}>
      <Solid size={[0.75, 1.52, 0.065]} color="#14201f" radius={0.095} metalness={0.2} roughness={0.24} />
      <mesh position={[0, 0.18, 0.036]}><planeGeometry args={[0.586, 0.88]} /><meshBasicMaterial map={texture} toneMapped={false} /></mesh>
      <mesh position={[0, -0.48, 0.05]} rotation={[Math.PI / 2, 0, 0]}><cylinderGeometry args={[0.099, 0.099, 0.035, 40]} /><meshStandardMaterial color="#162e3a" metalness={0.5} roughness={0.2} /></mesh>
      <mesh position={[0, -0.48, 0.071]}><torusGeometry args={[0.083, 0.008, 8, 40]} /><meshStandardMaterial color="#6ad2ff" emissive="#19a8fb" emissiveIntensity={1.5} /></mesh>
      <mesh position={[0, -0.478, 0.075]}><ringGeometry args={[0.027, 0.032, 28, 1, 0.65, 4.98]} /><meshBasicMaterial color="#b3eaff" /></mesh><mesh position={[0, -0.447, 0.076]}><planeGeometry args={[0.006, 0.035]} /><meshBasicMaterial color="#b3eaff" /></mesh>
      {exploded && labels && <Label position={[0.4, 1.1, 0.08]} title="05 / Front panel & display" subtitle="Touchscreen · Blue power button" />}
    </group>
    <group position={[0, 0.82, 0.03]}>
      <mesh castShadow><cylinderGeometry args={[0.1, 0.12, 0.15, 24]} /><meshStandardMaterial color="#dfe7df" roughness={0.3} /></mesh>
      <mesh position={[0, 0.08, 0.17]} rotation={[Math.PI / 2, 0, 0]} castShadow><cylinderGeometry args={[0.075, 0.075, 0.39, 24, 1, true]} /><meshPhysicalMaterial color="#f7fff4" roughness={0.18} transparent opacity={0.83} side={THREE.DoubleSide} /></mesh>
      <mesh position={[0, 0.08, 0.366]}><ringGeometry args={[0.05, 0.075, 24]} /><meshStandardMaterial color="#f4f8f0" side={THREE.DoubleSide} /></mesh>
      {inside && labels && <Label position={[0.02, 0.72, 0.15]} title="Removable mouthpiece" subtitle="Proposed hygienic inlet" />}
    </group>
    {!inside && <><Solid position={[0.423, 0.18, 0]} size={[0.013, 0.21, 0.09]} color="#aebcb5" radius={0.005} />{Array.from({ length: 5 }, (_, i) => <Solid key={i} position={[0.415, -0.38 + i * 0.038, 0]} size={[0.012, 0.014, 0.11]} color="#667870" radius={0.004} />)}</>}
  </group>
}
