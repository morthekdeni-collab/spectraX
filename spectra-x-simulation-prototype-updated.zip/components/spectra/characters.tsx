'use client'

import { useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { Device, Solid } from './device'
import type { Outcome } from '@/lib/simulation'

function Ellipsoid({ position, scale, color, roughness = 0.85 }: { position: [number, number, number]; scale: [number, number, number]; color: string; roughness?: number }) {
  return <mesh position={position} scale={scale} castShadow receiveShadow><sphereGeometry args={[1, 24, 20]} /><meshStandardMaterial color={color} roughness={roughness} /></mesh>
}

function Segment({ from, to, radius, color, endRadius }: { from: [number, number, number]; to: [number, number, number]; radius: number; color: string; endRadius?: number }) {
  const a = new THREE.Vector3(...from), b = new THREE.Vector3(...to)
  const direction = b.clone().sub(a)
  const rotation = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), direction.clone().normalize())
  return <mesh position={a.add(b).multiplyScalar(0.5)} quaternion={rotation} castShadow><cylinderGeometry args={[endRadius ?? radius * 0.85, radius, direction.length(), 16]} /><meshStandardMaterial color={color} roughness={0.85} /></mesh>
}

function Hand({ skin, position, grip = false }: { skin: string; position: [number, number, number]; grip?: boolean }) {
  return <group position={position}>
    <Ellipsoid position={[0, 0, 0]} scale={[0.052, 0.072, 0.045]} color={skin} />
    {[-2, -1, 0, 1, 2].map((i) => {
      const x = i * 0.018
      const bend = grip ? 0.012 + Math.abs(i) * 0.004 : 0
      return <group key={i} position={[x, -0.058, 0.012]}>
        <Ellipsoid position={[0, -bend, 0]} scale={[0.012, 0.035, 0.014]} color={skin} />
        <Ellipsoid position={[0, -0.066 - bend, 0.002]} scale={[0.011, 0.027, 0.013]} color={skin} />
      </group>
    })}
    <Ellipsoid position={[0.052, -0.018, 0.018]} scale={[0.018, 0.043, 0.016]} color={skin} />
  </group>
}

function Face({ skin, operator }: { skin: string; operator: boolean }) {
  return <group position={[0, 1.63, 0]}>
    <Ellipsoid position={[0, 0, 0]} scale={[0.107, 0.146, 0.108]} color={skin} />
    <Ellipsoid position={[0, -0.065, 0.025]} scale={[0.085, 0.082, 0.083]} color={skin} />
    <Ellipsoid position={[0, -0.005, 0.111]} scale={[0.022, 0.04, 0.033]} color={skin} />
    {[-1, 1].map((side) => <group key={side}>
      <Ellipsoid position={[side * 0.105, -0.008, -0.002]} scale={[0.02, 0.038, 0.021]} color={skin} />
      <Ellipsoid position={[side * 0.044, 0.022, 0.091]} scale={[0.024, 0.012, 0.014]} color="#e3dcd0" />
      <Ellipsoid position={[side * 0.044, 0.022, 0.102]} scale={[0.008, 0.009, 0.004]} color="#414335" />
      <Segment from={[side * 0.025, 0.045, 0.098]} to={[side * 0.067, 0.047, 0.085]} radius={0.005} color="#352c26" />
    </group>)}
    <Ellipsoid position={[0, -0.057, 0.101]} scale={[0.031, 0.006, 0.007]} color={operator ? '#916551' : '#9f6b5b'} />
    <mesh position={[0, 0.047, -0.015]} scale={[0.113, 0.119, 0.108]} castShadow><sphereGeometry args={[1, 24, 16, 0, Math.PI * 2, 0, 1.75]} /><meshStandardMaterial color={operator ? '#2b2723' : '#44372b'} roughness={0.95} /></mesh>
    <Ellipsoid position={[-0.028, 0.121, 0.02]} scale={[0.085, 0.034, 0.079]} color={operator ? '#2b2723' : '#44372b'} />
    {!operator && <Ellipsoid position={[0, -0.092, 0.053]} scale={[0.07, 0.027, 0.05]} color="#876859" />}
  </group>
}

export function Human({ operator, elapsed, stage, outcome, paused }: { operator: boolean; elapsed: number; stage: number; outcome: Outcome; paused: boolean }) {
  const root = useRef<THREE.Group>(null)
  const torso = useRef<THREE.Group>(null)
  const leftLeg = useRef<THREE.Group>(null)
  const rightLeg = useRef<THREE.Group>(null)
  const arm = useRef<THREE.Group>(null)
  const breathing = useRef<THREE.Group>(null)
  const skin = operator ? '#b79073' : '#c39a80'
  const shirt = operator ? '#38594f' : '#b7b0a0'
  const pants = operator ? '#303c3b' : '#4d5a60'
  const preparing = Math.max(0, Math.min(1, (elapsed - 7) / 4))
  const extension = operator ? preparing : 0
  const torsoGeometry = useMemo(() => new THREE.LatheGeometry([new THREE.Vector2(0.15, 0), new THREE.Vector2(0.158, 0.06), new THREE.Vector2(0.165, 0.17), new THREE.Vector2(0.195, 0.32), new THREE.Vector2(0.195, 0.39), new THREE.Vector2(0.145, 0.44), new THREE.Vector2(0.075, 0.47)], 28), [])
  useFrame(() => {
    const approach = Math.min(1, elapsed / 6.5)
    const operatorApproach = Math.max(0, Math.min(1, (elapsed - 3) / 4))
    const walking = stage === 1 && (operator ? operatorApproach > 0 && operatorApproach < 1 : approach < 1)
    const gait = walking ? Math.sin(elapsed * (operator ? 7 : 6.2)) : 0
    if (root.current) {
      root.current.position.x = operator ? 0.55 + (1 - operatorApproach) * 0.7 : -0.61 - (1 - approach) * 1.8
      root.current.position.z = operator ? 0.13 : 0.17 + (walking && elapsed > 2.5 ? Math.sin(elapsed * 2.6) * 0.08 : 0)
      root.current.position.y = walking ? Math.abs(gait) * 0.019 : 0
      root.current.rotation.y = operator ? -Math.PI / 2 : Math.PI / 2
    }
    if (torso.current) {
      torso.current.rotation.z = walking && !operator && elapsed > 2.5 ? Math.sin(elapsed * 2.3) * 0.075 : 0
      torso.current.rotation.x = !operator && stage > 0 ? 0.055 : 0
    }
    if (leftLeg.current) leftLeg.current.rotation.x = gait * 0.36
    if (rightLeg.current) rightLeg.current.rotation.x = -gait * 0.36
    if (arm.current) arm.current.rotation.x = -gait * 0.24
    if (breathing.current) {
      const breath = stage === 3 ? Math.sin(elapsed * 3.2) * 0.018 : Math.sin(elapsed * 1.5) * 0.006
      breathing.current.scale.y = 1 + breath
    }
  })
  return <group ref={root}>
    {[-1, 1].map((side) => <group ref={side === -1 ? leftLeg : rightLeg} key={side} position={[side * 0.093, 0.88, 0]}>
      <Segment from={[0, 0, 0]} to={[0, -0.4, 0.005]} radius={0.083} endRadius={0.067} color={pants} />
      <Ellipsoid position={[0, -0.4, 0.005]} scale={[0.068, 0.065, 0.07]} color={pants} />
      <Segment from={[0, -0.4, 0.005]} to={[0, -0.78, 0]} radius={0.064} endRadius={0.049} color={pants} />
      <Solid position={[0, -0.813, 0.045]} size={[0.115, 0.09, 0.24]} radius={0.04} color={operator ? '#252d2b' : '#383b35'} />
      <Solid position={[0, -0.85, 0.043]} size={[0.119, 0.024, 0.242]} radius={0.009} color="#64675b" />
    </group>)}
    <Ellipsoid position={[0, 0.91, 0]} scale={[0.175, 0.115, 0.107]} color={pants} />
    <group ref={torso}><group ref={breathing}>
      <mesh geometry={torsoGeometry} position={[0, 0.98, 0]} scale={[1, 1, 0.64]} castShadow receiveShadow><meshStandardMaterial color={shirt} roughness={0.95} /></mesh>
      <mesh position={[0, 1.485, 0]} castShadow><cylinderGeometry args={[0.055, 0.069, 0.13, 20]} /><meshStandardMaterial color={skin} roughness={0.85} /></mesh>
      <Face operator={operator} skin={skin} />
      <Solid position={[0, 0.985, 0]} size={[0.315, 0.03, 0.206]} radius={0.01} color={operator ? '#293d32' : '#6b6b5d'} />
      <Solid position={[0, 0.985, 0.108]} size={[0.045, 0.035, 0.012]} color="#9ca294" radius={0.003} metalness={0.8} />
      {operator && <><Segment from={[-0.06, 1.45, 0.077]} to={[0, 1.23, 0.139]} radius={0.006} color="#9fac91" /><Segment from={[0.06, 1.45, 0.077]} to={[0, 1.23, 0.139]} radius={0.006} color="#9fac91" /><Solid position={[0, 1.2, 0.145]} size={[0.073, 0.093, 0.006]} color="#e5e9df" radius={0.007} /><Solid position={[0, 1.22, 0.15]} size={[0.042, 0.032, 0.003]} color="#6c897a" radius={0.002} /></>}
      {!operator && <><Segment from={[-0.05, 1.43, 0.075]} to={[0, 1.36, 0.125]} radius={0.012} color="#c8c1b0" /><Segment from={[0.05, 1.43, 0.075]} to={[0, 1.36, 0.125]} radius={0.012} color="#c8c1b0" /></>}
      <group ref={arm}><Segment from={[-0.2, 1.37, 0]} to={[-0.235, 1.09, 0.02]} radius={0.069} color={shirt} /><Ellipsoid position={[-0.234, 1.09, 0.02]} scale={[0.052, 0.055, 0.056]} color={shirt} /><Segment from={[-0.235, 1.09, 0.02]} to={[-0.228, 0.88, 0.055]} radius={0.047} endRadius={0.034} color={operator ? skin : shirt} /><Hand skin={skin} position={[-0.23, 0.82, 0.062]} /></group>
      <Segment from={[0.2, 1.37, 0]} to={[0.25, 1.09 + extension * 0.09, 0.02 + extension * 0.3]} radius={0.069} endRadius={0.052} color={shirt} />
      <Ellipsoid position={[0.25, 1.09 + extension * 0.09, 0.02 + extension * 0.3]} scale={[0.051, 0.055, 0.055]} color={shirt} />
      <Segment from={[0.25, 1.09 + extension * 0.09, 0.02 + extension * 0.3]} to={[0.22 - extension * 0.14, 0.88 + extension * 0.42, 0.055 + extension * 0.72]} radius={0.043} endRadius={0.031} color={operator ? skin : shirt} />
      <Hand skin={skin} position={[0.22 - extension * 0.14, 0.82 + extension * 0.51, 0.062 + extension * 0.74]} grip={operator && extension > 0.55} />
      {operator && <group position={[0.04, 0.92 + extension * 0.41, 0.1 + extension * 0.72]} scale={0.27}><Device stage={stage} outcome={outcome} elapsed={elapsed} paused={paused} /></group>}
      </group>
    </group>
  </group>
}
