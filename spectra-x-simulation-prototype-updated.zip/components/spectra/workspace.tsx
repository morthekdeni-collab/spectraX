'use client'

import dynamic from 'next/dynamic'
import { useEffect, useRef, useState } from 'react'
import { Activity, ArrowDownRight, ArrowUpRight, AudioLines, Box, Check, ChevronRight, CircleHelp, Cpu, Expand, FlaskConical, Focus, Info, Layers3, Maximize2, Minus, MousePointer2, Pause, Play, Plus, RotateCcw, RotateCw, ScanLine, ShieldCheck, Wind, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { ResultPanel } from './result-panel'
import { getStage, sensors, stages, TOTAL_DURATION, type InspectionView, type Outcome } from '@/lib/simulation'
import { cn } from '@/lib/utils'

const SimulationScene = dynamic(() => import('./simulation-scene'), { ssr: false, loading: () => <div className="scene-loading"><Box /><span>Preparing the 3D environment</span><small>Proposed design · Simulation only</small></div> })
const stageIcons = [MousePointer2, ScanLine, Wind, Activity, Cpu, ShieldCheck]
const viewNames: Record<InspectionView, string> = { scene: 'Demonstration area', device: 'Device inspection', exploded: 'Exploded assembly', sensors: 'Sensor chamber', airflow: 'Proposed airflow path', processing: 'Processing board' }

export function Workspace() {
  const [elapsed, setElapsed] = useState(0)
  const [started, setStarted] = useState(false)
  const [paused, setPaused] = useState(false)
  const [outcome, setOutcome] = useState<Outcome>('positive')
  const [view, setView] = useState<InspectionView>('scene')
  const [followSequence, setFollowSequence] = useState(true)
  const [rotate, setRotate] = useState(false)
  const [zoom, setZoom] = useState(1)
  const [cameraKey, setCameraKey] = useState(0)
  const [info, setInfo] = useState<'about' | 'help' | null>(null)
  const [expanded, setExpanded] = useState(false)
  const [ready, setReady] = useState(false)
  const viewer = useRef<HTMLDivElement>(null)
  const dialog = useRef<HTMLDialogElement>(null)
  const stage = getStage(elapsed, started)
  const running = started && !paused && stage < 6

  useEffect(() => {
    if (!running) return
    let previous = performance.now()
    const timer = window.setInterval(() => {
      const now = performance.now()
      const delta = Math.min((now - previous) / 1000, 0.25)
      previous = now
      setElapsed((time) => Math.min(TOTAL_DURATION, time + delta))
    }, 50)
    return () => window.clearInterval(timer)
  }, [running])

  useEffect(() => {
    if (info) dialog.current?.showModal()
    else dialog.current?.close()
  }, [info])

  function reset() {
    setElapsed(0); setStarted(false); setPaused(false); setView('scene'); setFollowSequence(true); setRotate(false); setZoom(1); setCameraKey((key) => key + 1)
  }
  function start() {
    setElapsed(0); setStarted(true); setPaused(false); setView('scene'); setFollowSequence(true); setRotate(false); setZoom(1); setCameraKey((key) => key + 1)
  }
  function inspect(next: InspectionView) {
    setView(next); setFollowSequence(false); setZoom(1); setRotate(false); setCameraKey((key) => key + 1)
  }
  function showResult() { setElapsed(TOTAL_DURATION); setStarted(true); setPaused(false); inspect('device') }
  const visibleView = followSequence && view === 'scene' && stage >= 4 ? (stage === 4 ? 'sensors' : stage === 5 ? 'processing' : 'device') : view
  const isDevice = visibleView !== 'scene'

  return (
    <div className="spectra-app">
      <header className="app-header">
        <a href="#" className="brand" aria-label="SPECTRA X home" onClick={(e) => { e.preventDefault(); reset() }}><span className="brand-mark"><AudioLines /></span><span>SPECTRA <b>X</b><small>BIOMEDICAL ENGINEERING</small></span></a>
        <nav aria-label="Main navigation"><button className={view === 'scene' ? 'nav-active' : ''} onClick={() => inspect('scene')}>Simulation</button><button className={view !== 'scene' ? 'nav-active' : ''} onClick={() => inspect('exploded')}>Device architecture<ArrowUpRight size={12} /></button><button onClick={() => setInfo('about')}>About the prototype</button></nav>
        <span className="prototype-badge"><span /> DIGITAL PROTOTYPE <span className="version">V.01</span></span>
      </header>
      <main className="app-main">
        <section className="intro">
          <div><div className="intro-eyebrow"><span /> CONCEPT TO POSSIBILITY</div><h1>A breath. A signal. <span>A new perspective.</span></h1><p>SPECTRA X — Breath-Based Detection Device for Drug Consumption</p></div>
          <button className="guide-link" onClick={() => setInfo('help')}><CircleHelp size={16} /> How to explore <ArrowUpRight size={14} /></button>
        </section>
        <div className="workspace-grid">
          <div className="demo-column">
            <section className={cn('viewer-card', expanded && 'viewer-expanded')} ref={viewer} aria-label="Interactive 3D simulation">
              <div className="viewer-heading"><div><span className="section-dot" /><h2>Live demonstration</h2><span className="viewer-divider" /><span className="viewer-subtitle">{viewNames[visibleView]}</span></div><span className="ready-pill"><span />{paused ? 'Paused' : stages[stage].short === 'Ready' ? 'System ready' : stages[stage].title}</span></div>
              <div className="scene-wrapper" data-ready={ready}>
                <SimulationScene elapsed={elapsed} stage={stage} paused={paused} outcome={outcome} view={visibleView} rotating={rotate} zoom={zoom} cameraKey={cameraKey} onReady={() => setReady(true)} />
                <div className="scene-topline"><span><span className="record-dot" /> {isDevice ? 'PROPOSED DEVICE DESIGN' : 'CONTROLLED DEMONSTRATION AREA'}</span><span className="mono">{String(Math.floor(elapsed / 60)).padStart(2, '0')}:{String(Math.floor(elapsed % 60)).padStart(2, '0')}</span></div>
                <div className="view-switch" aria-label="Scene view"><button aria-pressed={!isDevice} className={cn(!isDevice && 'selected')} onClick={() => inspect('scene')}><Box size={14} /> Scene</button><button aria-pressed={isDevice} className={cn(isDevice && 'selected')} onClick={() => inspect('device')}><ScanLine size={14} /> Device</button></div>
                <div className="viewport-tools"><button title="Zoom in" aria-label="Zoom in" disabled={zoom >= 1.7} onClick={() => setZoom((z) => Math.min(1.7, z + 0.15))}><Plus /></button><button title="Zoom out" aria-label="Zoom out" disabled={zoom <= 0.65} onClick={() => setZoom((z) => Math.max(0.65, z - 0.15))}><Minus /></button><span /><button title="Reset camera" aria-label="Reset camera" onClick={() => { setZoom(1); setCameraKey((key) => key + 1) }}><Focus /></button><button title={expanded ? 'Close expanded scene' : 'Expand scene'} aria-label={expanded ? 'Close expanded scene' : 'Expand scene'} onClick={() => setExpanded(!expanded)}>{expanded ? <X /> : <Maximize2 />}</button></div>
                {(visibleView === 'sensors' || visibleView === 'processing' || visibleView === 'airflow') && <div className="signal-overlay"><div className="signal-bars" aria-hidden="true">{Array.from({ length: 18 }, (_, i) => <span key={i} style={{ animationDelay: `${-i * 0.19}s`, animationDuration: `${0.6 + (i % 5) * 0.23}s`, animationPlayState: paused ? 'paused' : 'running' }} />)}</div><div className="signal-copy">
<strong>{visibleView === 'airflow' ? 'MOUTHPIECE → CHAMBER → SENSOR ARRAY → EXHAUST' : visibleView === 'sensors' ? 'MULTI-SENSOR DETECTION' : 'BREATH SAMPLE → SENSOR ARRAY → ADS1115 → ESP32-S3'}</strong>
<small>{visibleView === 'airflow' ? 'Proposed airflow path — schematic simulation' : visibleView === 'sensors' ? 'TCS34725 (color sensor) acts as a digital colorimeter or spectrophotometer sensor' : 'Illustrative signal patterns · No measured concentrations · No trained AI model'}</small></div></div>}
                <div className="scene-bottomline"><span><MousePointer2 size={12} /> Drag to orbit <span className="hint-dot">·</span> Scroll to zoom</span><span className="schematic-label">{visibleView === 'airflow' ? 'PROPOSED AIRFLOW PATH — SCHEMATIC SIMULATION' : '3D CONCEPT · NOT PHYSICAL HARDWARE'}</span></div>
                {stage > 0 && stage < 4 && !isDevice && <div className="scenario-caption"><span>{stage === 1 ? 'SCENARIO STARTED' : stage === 2 ? 'SPECTRA X · BREATH SAMPLE COLLECTION' : 'BREATH COLLECTION'}</span><strong>{stage === 1 ? 'Demonstration subject approaching' : stage === 2 ? 'Please blow into the mouthpiece' : 'Airflow active — simulated'}</strong><small>{stage === 1 ? 'Visual behavior is not a diagnostic measurement.' : 'Sample status: Simulated'}</small></div>}
              </div>
              <div className="inspection-toolbar"><span className="toolbar-label">INSPECT</span><button aria-pressed={rotate} onClick={() => { if (!isDevice) inspect('device'); setRotate(!rotate) }}><RotateCw size={14} /> Rotate device</button><button aria-pressed={visibleView === 'exploded'} onClick={() => inspect(visibleView === 'exploded' ? 'device' : 'exploded')}><Layers3 size={14} />{visibleView === 'exploded' ? 'Close exploded view' : 'Exploded view'}</button><button aria-pressed={visibleView === 'sensors'} onClick={() => inspect('sensors')}><ScanLine size={14} /> Sensor chamber</button><button aria-pressed={visibleView === 'airflow'} onClick={() => inspect('airflow')}><Wind size={14} /> Airflow</button><button aria-pressed={visibleView === 'processing'} onClick={() => inspect('processing')}><Cpu size={14} /> Processing</button></div>
              <div className="playback-controls"><Button size="lg" className="h-11 px-6" onClick={start} disabled={!ready || (started && stage < 6)}><Play data-icon="inline-start" fill="currentColor" />{stage === 6 ? 'Run simulation again' : 'Start simulation'}</Button><Button variant="outline" className="h-11" disabled={!started || stage === 6} onClick={() => setPaused(!paused)}>{paused ? <Play data-icon="inline-start" /> : <Pause data-icon="inline-start" />}{paused ? 'Resume' : 'Pause'}</Button><Button variant="ghost" className="h-11" onClick={reset}><RotateCcw data-icon="inline-start" /> Reset scene</Button><span className="playback-note"><span />{stage === 0 ? 'One click. The complete story.' : paused ? 'Paused · inspect at your own pace' : stage === 6 ? 'Complete · explore the device' : 'Guided sequence in progress'}</span></div>
            </section>
            <section className="journey-section" aria-label="Simulation sequence"><div className="section-heading"><h2>The journey of a breath</h2><span>6 STAGES · ONE CONNECTED PROCESS</span></div><ol className="journey-steps">{stages.slice(1).map((s, i) => { const Icon = stageIcons[i]; return <li key={s.short} className={cn(stage === i + 1 && 'current', stage > i + 1 && 'complete')}><div className="journey-top"><span className="journey-icon">{stage > i + 1 ? <Check /> : <Icon />}</span><span className="mono">0{i + 1}</span></div><span>{s.short}</span><div className="journey-track"><div style={{ width: stage > i + 1 ? '100%' : stage === i + 1 ? `${stage === 6 ? 100 : (elapsed - s.start) / (s.end - s.start) * 100}%` : '0%' }} /></div></li> })}</ol></section>
          </div>
          <ResultPanel stage={stage} elapsed={elapsed} paused={paused} outcome={outcome} setOutcome={setOutcome} showResult={showResult} reset={reset} />
        </div>
        <section className="sensor-section"><div className="sensor-section-title"><span className="mini-icon"><Cpu /></span><div><h2>Multi-sensor detection</h2><p>The proposed sensing & processing architecture</p></div><span className="sensor-simulation-note"><span /> ALL SIGNALS SIMULATED</span></div><div className="sensor-grid">{sensors.map((sensor, i) => <button key={sensor.id} onClick={() => { inspect(i === 5 ? 'processing' : 'sensors'); viewer.current?.scrollIntoView({ behavior: 'smooth', block: 'center' }) }} className={cn('sensor-item', stage >= 4 && 'sensor-active')}><span className="sensor-chip"><Cpu size={18} /></span><span><strong>{sensor.id}</strong><small>{sensor.short}</small></span><ArrowUpRight size={13} /></button>)}</div></section>
        <section className="prototype-disclaimer"><Info size={17} /><div><strong>DIGITAL 3D SIMULATION</strong><p>Hardware has not yet been physically assembled. Sensor values and classification results are simulated.<br className="desktop-break" /> Demonstration results are not medical or forensic evidence.</p></div><span>Designed to explain.<br />Not to diagnose.</span></section>
      </main>
      <footer className="app-footer"><span>SPECTRA X <span className="footer-slash">/</span> An exploration in biomedical engineering</span><span>CONCEPT PROTOTYPE <span className="footer-dot">·</span> PRESENTATION EDITION</span></footer>
      <div className="safety-bar"><Info size={12} /><strong>DIGITAL 3D SIMULATION</strong><span>Hardware not assembled · Sensor values and results simulated · Not medical or forensic evidence</span></div>
      <dialog ref={dialog} className="info-dialog" onCancel={() => setInfo(null)} onClick={(e) => { if (e.target === dialog.current) setInfo(null) }}><div className="dialog-heading"><span className="brand-mark"><AudioLines /></span><Button variant="ghost" size="icon" aria-label="Close information" onClick={() => setInfo(null)}><X /></Button></div><span className="eyebrow">SPECTRA X · DIGITAL CONCEPT</span><h2>{info === 'about' ? 'A concept, not a clinical claim.' : 'Your guide to the demonstration.'}</h2>{info === 'about' ? <><p>SPECTRA X explores a proposed handheld breath-based screening workflow for a college engineering presentation. This is a procedural 3D prototype; no hardware has been assembled, and no clinical or forensic performance has been established.</p><p>The named components illustrate an engineering architecture. VOC and environmental sensors do not establish drug-specific identification. Sensor signals, AI processing, and all results are scripted simulations, not measurements or real model predictions.</p><p>Character motion is staged independently from the chosen outcome. Appearance and movement are not diagnostic evidence.</p><p>The device follows the written design specification. The human figures are procedurally modeled, not photorealistic scans.</p></> : <ol className="help-steps"><li><Play /><div><strong>Start the story</strong><p>Choose a scripted outcome and select Start simulation. The complete sequence runs automatically in 36 seconds.</p></div></li><li><MousePointer2 /><div><strong>Take a closer look</strong><p>Drag to orbit, scroll to zoom, or use the inspection controls. Pause freezes the guided sequence.</p></div></li><li><Layers3 /><div><strong>Explore the proposed design</strong><p>Open the exploded assembly, airflow path, sensor chamber, or processing board. Component labels identify the proposed arrangement.</p></div></li><li><ShieldCheck /><div><strong>Read the result responsibly</strong><p>The same scripted result appears on the device and audience panel. Show simulated result skips directly to that outcome.</p></div></li></ol>}<Button className="w-full h-11" onClick={() => setInfo(null)}>Return to the demonstration<ArrowDownRight data-icon="inline-end" /></Button></dialog>
    </div>
  )
}
