'use client'

import { Activity, ArrowRight, Check, CheckCheck, Fingerprint, FlaskConical, LoaderCircle, ScanLine, ShieldCheck, Wind } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { analysisSteps, getStageProgress, outcomes, stages, type Outcome } from '@/lib/simulation'

interface ResultPanelProps {
  stage: number
  elapsed: number
  paused: boolean
  outcome: Outcome
  setOutcome: (outcome: Outcome) => void
  showResult: () => void
  reset: () => void
}

export function ResultPanel({ stage, elapsed, paused, outcome, setOutcome, showResult, reset }: ResultPanelProps) {
  const result = outcomes[outcome]
  const complete = stage === 6
  const progress = getStageProgress(elapsed, stage)
  const step = Math.min(4, Math.floor((elapsed - 27) / 1.8))
  return (
    <aside className="audience-panel" aria-label="Audience-facing simulation result">
      <div className="panel-heading"><span className="eyebrow">SIMULATION OVERVIEW</span><span className="live-tag"><span /> LIVE</span></div>
      <div className="stage-summary">
        <span className="subtle-label">CURRENT STAGE <span className="mono">{String(Math.min(stage, 6)).padStart(2, '0')} / 06</span></span>
        <h2 aria-live="polite">{paused ? 'Simulation paused' : stages[stage].title}</h2>
        <p>{stages[stage].detail}</p>
        <div className="progress-track" role="progressbar" aria-label="Overall simulation progress" aria-valuenow={Math.round(elapsed / 36 * 100)} aria-valuemin={0} aria-valuemax={100}><div style={{ width: `${elapsed / 36 * 100}%` }} /></div>
        <div className="progress-caption"><span>{stage === 0 ? 'Waiting to start' : complete ? 'Sequence complete' : `Stage ${stage} of 6`}</span><span className="mono">{Math.round(elapsed / 36 * 100)}%</span></div>
      </div>
      <div className={`result-display ${complete ? `result-${outcome}` : ''}`} aria-live="polite" aria-atomic="true">
        <div className="result-kicker"><ScanLine size={14} /> SPECTRA X · SIMULATION RESULT</div>
        <div className={`result-symbol ${stage > 0 && !complete && !paused ? 'is-processing' : ''}`}>
          {complete ? (outcome === 'negative' ? <ShieldCheck /> : <FlaskConical />) : stage === 3 ? <Wind /> : stage >= 4 ? <Activity /> : <Fingerprint />}
        </div>
        <h3>{complete ? result.title : stage === 0 ? 'Ready when you are.' : stage === 3 ? 'Receiving a breath sample' : stage >= 4 ? 'Making sense of the signals' : 'A closer look starts here.'}</h3>
        <p>{complete ? result.description : 'Follow each step from breath collection to a simulated result.'}</p>
        {complete ? <><div className="result-followup">{result.followup}</div><span className="result-stamp">SIMULATED RESULT — NOT A MEDICAL DIAGNOSIS</span></> : <span className="awaiting-label"><span /> {stage === 0 ? 'AWAITING SIMULATION' : paused ? 'SEQUENCE PAUSED' : 'SIMULATION IN PROGRESS'}</span>}
      </div>
      <div className="device-status">
        <div><span>Device status</span><strong><span className="status-dot" />{stage === 0 ? 'Ready' : complete ? 'Result available' : paused ? 'Paused' : 'Simulating'}</strong></div>
        <div><span>Hardware connection</span><span className="muted-value">Not implemented</span></div>
        <div><span>Classification model</span><span className="muted-value">Demonstration mode</span></div>
      </div>
      {stage === 3 && <div className="stage-details"><div><Check size={13} /> Mouthpiece: Ready</div><div><Wind size={13} /> Airflow: Active — simulated</div><div><LoaderCircle size={13} /> Collection chamber: Receiving sample</div><div>Sample status: Simulated · {Math.round(progress)}%</div></div>}
      {stage === 5 && <ol className="analysis-steps">{analysisSteps.map((label, i) => <li key={label} className={i <= step ? 'step-reached' : ''}>{i < step ? <Check size={12} /> : <span className="step-number">{i + 1}</span>}{label}</li>)}</ol>}
      <div className="outcome-control"><label htmlFor="outcome">Demonstration outcome <span>SCRIPTED</span></label><select id="outcome" value={outcome} disabled={stage > 0 && stage < 6} onChange={(e) => setOutcome(e.target.value as Outcome)}><option value="positive">Presumptive positive</option><option value="negative">Negative</option><option value="inconclusive">Inconclusive</option></select><p>Selected for demonstration, never inferred from appearance.</p></div>
      <Button variant="outline" className="w-full h-10" onClick={complete ? reset : showResult}>{complete ? <CheckCheck data-icon="inline-start" /> : <ScanLine data-icon="inline-start" />}{complete ? 'Return to ready' : 'Show simulated result'}<ArrowRight data-icon="inline-end" /></Button>
    </aside>
  )
}
