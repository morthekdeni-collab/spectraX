'use client'

import { Component, Suspense, useEffect, useMemo, useRef, type ReactNode, type ComponentRef } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { Grid, Html, OrbitControls } from '@react-three/drei'
import * as THREE from 'three'
import { Device, Solid } from './device'
import { Human } from './characters'
import type { InspectionView, Outcome } from '@/lib/simulation'

interface SceneProps {
  elapsed: number
  stage: number
  paused: boolean
  outcome: Outcome
  view: InspectionView
  rotating: boolean
  zoom: number
  cameraKey: number
  onReady: () => void
}

function Sign({ position, title, subtitle, green = false }: { position: [number, number, number]; title: string; subtitle?: string; green?: boolean }) {
  return <Html center position={position} distanceFactor={5.5} zIndexRange={[4, 0]}><div className={`scene-sign ${green ? 'sign-green' : ''}`}><span>{title}</span>{subtitle && <small>{subtitle}</small>}</div></Html>
}

function Environment() {
  return <group>
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.15, 0]} receiveShadow><planeGeometry args={[200, 200]} /><meshStandardMaterial color="#e4e9e1" roughness={1} /></mesh>
    <Grid position={[0, -0.143, 0]} args={[80, 80]} cellSize={0.75} sectionSize={3.75} cellThickness={0.45} sectionThickness={0.65} cellColor="#bac9bc" sectionColor="#bac9bc" fadeDistance={16} fadeStrength={1.8} infiniteGrid />
    <Solid position={[-0.7, -0.095, 0]} size={[6.4, 0.15, 4.1]} color="#d6ded3" radius={0.07} />
    <Solid position={[-0.7, -0.014, 0]} size={[6.28, 0.035, 3.98]} color="#e9ece3" radius={0.025} />
    <Solid position={[-0.75, 0.008, 0.26]} size={[2.7, 0.012, 2.04]} color="#d2ded0" radius={0.12} />
    {[-1.98, 0.5].map((x) => [-0.65, 1.15].map((z) => <group key={`${x}-${z}`}><Solid position={[x, 0.018, z]} size={[0.26, 0.008, 0.025]} color="#6d947b" radius={0.003} /><Solid position={[x + (x < 0 ? -0.12 : 0.12), 0.018, z + (z < 0 ? 0.12 : -0.12)]} size={[0.025, 0.008, 0.26]} color="#6d947b" radius={0.003} /></group>))}
    <Solid position={[-1.1, 1.23, -1.48]} size={[4.2, 2.46, 0.1]} color="#d0dcd0" radius={0.035} />
    <Solid position={[-1.1, 2.45, -1.45]} size={[4.35, 0.075, 0.21]} color="#899f8c" radius={0.025} />
    {[-3.15, 0.93].map((x) => <Solid key={x} position={[x, 1.22, -1.4]} size={[0.07, 2.45, 0.12]} color="#91a38e" radius={0.012} />)}
    {Array.from({ length: 9 }, (_, i) => <Solid key={i} position={[-3 + i * 0.45, 0.54, -1.418]} size={[0.01, 1, 0.007]} color="#b5c5b5" radius={0.003} />)}
    <Sign position={[-1.65, 1.98, -1.37]} title="SPECTRA X" subtitle="BREATH · SIGNAL · POSSIBILITY" green />
    <Sign position={[0.24, 1.87, -1.37]} title="01" subtitle="DEMONSTRATION AREA" />
    <Solid position={[1.32, 0.4, -0.73]} size={[1.05, 0.8, 0.85]} color="#c1cebd" radius={0.05} />
    <Solid position={[1.32, 0.82, -0.73]} size={[1.12, 0.075, 0.9]} color="#f3f3e8" radius={0.025} />
    <Solid position={[1.49, 0.94, -0.78]} size={[0.3, 0.17, 0.2]} color="#e1e9dc" radius={0.02} />
    <Solid position={[1.2, 0.865, -0.59]} size={[0.36, 0.02, 0.27]} color="#527462" radius={0.005} />
    {[-2.98, 1.35].map((x) => <group key={x} position={[x, 0, 1.66]}>
      <Solid position={[0, 0.035, 0]} size={[0.3, 0.07, 0.3]} color="#667565" radius={0.035} />
      <mesh position={[0, 0.39, 0]} castShadow><cylinderGeometry args={[0.028, 0.042, 0.72, 16]} /><meshStandardMaterial color="#9aa596" metalness={0.6} roughness={0.35} /></mesh>
      <Solid position={[0, 0.78, 0]} size={[0.105, 0.16, 0.105]} color="#415b48" radius={0.02} />
    </group>)}
    <Solid position={[-2.98, 0.7, 0.91]} size={[0.035, 0.1, 1.5]} color="#587360" radius={0.005} />
    <group position={[-3.4, 0, -0.85]}><Solid position={[0, 0.23, 0]} size={[0.37, 0.46, 0.37]} color="#bbc6b3" radius={0.05} />{Array.from({ length: 7 }, (_, i) => <mesh key={i} position={[Math.sin(i * 2) * 0.12, 0.61 + i * 0.028, Math.cos(i * 2) * 0.1]} rotation={[Math.sin(i) * 0.6, i, Math.cos(i) * 0.3]} scale={[0.08, 0.3, 0.05]} castShadow><sphereGeometry args={[1, 12, 10]} /><meshStandardMaterial color={i % 2 ? '#698061' : '#829574'} roughness={1} /></mesh>)}</group>
  </group>
}

function Breath({ elapsed, active }: { elapsed: number; active: boolean }) {
  const particles = useRef<THREE.Group>(null)
  useFrame(() => { particles.current?.children.forEach((particle, i) => { const t = (elapsed * 0.6 + i / 22) % 1; particle.position.set(-0.44 + t * 0.07, 1.575 + Math.sin(i * 4) * 0.025 * (1 - t), 0.17 + Math.cos(i * 3) * 0.022); const size = 0.65 + Math.sin(t * Math.PI) * 0.5; particle.scale.setScalar(size) }) })
  return <group ref={particles} visible={active}>{Array.from({ length: 22 }, (_, i) => <mesh key={i}><sphereGeometry args={[0.012, 8, 8]} /><meshBasicMaterial color="#5ad6c0" transparent opacity={0.75} /></mesh>)}</group>
}

function DigitalTwin({ stage, outcome, elapsed, paused }: Pick<SceneProps, 'stage' | 'outcome' | 'elapsed' | 'paused'>) {
  return <group position={[2.32, 0, 1.02]}>
    <mesh position={[0, 0.025, 0]} receiveShadow castShadow><cylinderGeometry args={[0.77, 0.81, 0.17, 64]} /><meshStandardMaterial color="#bdcbbb" roughness={0.65} /></mesh>
    <mesh position={[0, 0.116, 0]} rotation={[-Math.PI / 2, 0, 0]}><ringGeometry args={[0.71, 0.72, 64]} /><meshBasicMaterial color="#6f9d7a" /></mesh>
    <group position={[0, 1.04, 0]} rotation={[0.03, -0.24, -0.07]} scale={0.93}><Device stage={stage} outcome={outcome} elapsed={elapsed} paused={paused} /></group>
    <Sign position={[0, 2.24, 0]} title="THE PROPOSED DEVICE" subtitle="SPECTRA X · DIGITAL TWIN" />
  </group>
}

function CameraRig({ view, stage, zoom, cameraKey, rotating, paused }: Pick<SceneProps, 'view' | 'stage' | 'zoom' | 'cameraKey' | 'rotating' | 'paused'>) {
  const controls = useRef<ComponentRef<typeof OrbitControls>>(null)
  const transition = useRef(true)
  const target = useMemo(() => new THREE.Vector3(), [])
  const position = useMemo(() => new THREE.Vector3(), [])
  useEffect(() => { transition.current = true }, [view, stage, zoom, cameraKey])
  useFrame(({ camera }, delta) => {
    if (!controls.current) return
    if (transition.current) {
      const close = view === 'scene' && stage >= 2 && stage < 4
      target.set(view === 'scene' ? close ? -0.2 : -0.1 : view === 'exploded' ? 0.03 : 0, view === 'scene' ? close ? 1.08 : 0.95 : 0.09, view === 'scene' ? 0 : 0)
      position.set(...(view === 'scene' ? close ? [3.3, 2.75, 5.1] : [4.6, 3.6, 7.6] : view === 'exploded' ? [2.5, 1.35, 6.1] : view === 'device' ? [1.7, 1.15, 4.3] : [0.9, 0.75, 3.6]) as [number, number, number])
      const aspect = camera instanceof THREE.PerspectiveCamera ? camera.aspect : 1.5
      position.sub(target).multiplyScalar(Math.max(1, 1.25 / aspect)).divideScalar(zoom).add(target)
      const damping = 1 - Math.exp(-delta * 3.7)
      camera.position.lerp(position, damping)
      controls.current.target.lerp(target, damping)
      if (camera.position.distanceTo(position) < 0.008 && controls.current.target.distanceTo(target) < 0.008) transition.current = false
      controls.current.update()
    }
  })
  return <OrbitControls ref={controls} makeDefault enableDamping dampingFactor={0.07} minDistance={1.5} maxDistance={16} maxPolarAngle={Math.PI * 0.49} minPolarAngle={0.2} autoRotate={rotating && !paused} autoRotateSpeed={1.4} onStart={() => { transition.current = false }} />
}

function SceneContents(props: SceneProps) {
  const { view, stage, elapsed, outcome, paused } = props
  const inspected = view !== 'scene'
  return <>
    <color attach="background" args={['#e7ece4']} />
    <fog attach="fog" args={['#e7ece4', 15, 38]} />
    <ambientLight intensity={1.05} />
    <hemisphereLight color="#fffdf0" groundColor="#7c9276" intensity={1.4} />
    <directionalLight position={[-3, 8, 5]} intensity={2.6} castShadow shadow-mapSize={[2048, 2048]} shadow-camera-left={-8} shadow-camera-right={8} shadow-camera-top={8} shadow-camera-bottom={-8} shadow-normalBias={0.025} shadow-bias={-0.0001} />
    <directionalLight position={[5, 3, -3]} intensity={1.1} color="#f3fff5" />
    <CameraRig {...props} />
    {inspected ? <>
      <group rotation={[0, -0.12, 0]}><Device stage={stage} outcome={outcome} view={view} elapsed={elapsed} paused={paused} labels /></group>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -1.11, 0]} receiveShadow><planeGeometry args={[200, 200]} /><meshStandardMaterial color="#e3e9df" roughness={0.85} /></mesh>
      <Grid position={[0, -1.103, 0]} args={[30, 30]} cellColor="#c4d2bf" sectionColor="#b7c9b2" cellSize={0.4} sectionSize={2} cellThickness={0.4} fadeDistance={9} fadeStrength={2} />
      {view === 'airflow' && <Sign position={[0, -1.36, 0.18]} title="MOUTHPIECE → CHAMBER → SENSOR ARRAY → EXHAUST" subtitle="PROPOSED AIRFLOW PATH · SCHEMATIC SIMULATION" />}
      {view === 'processing' && <Sign position={[0, -1.36, 0.18]} title="SAMPLE → SENSOR ARRAY → ADS1115 → ESP32-S3" subtitle="SIMULATED SIGNALS · NO HARDWARE CONNECTION" />}
    </> : <><Environment /><Human operator={false} elapsed={elapsed} stage={stage} outcome={outcome} paused={paused} /><Human operator elapsed={elapsed} stage={stage} outcome={outcome} paused={paused} /><Breath elapsed={elapsed} active={stage === 3} /><DigitalTwin {...props} /><Sign position={[-1.78, 0.05, 1.2]} title="DEMONSTRATION SUBJECT" /><Sign position={[0.42, 0.05, 1.15]} title="DEVICE OPERATOR" /></>}

  </>
}

class SceneErrorBoundary extends Component<{ children: ReactNode }, { failed: boolean }> {
  state = { failed: false }
  static getDerivedStateFromError() { return { failed: true } }
  render() { return this.state.failed ? <div className="scene-loading"><strong>3D rendering is unavailable</strong><span>Please open this page in a browser with WebGL enabled.</span><small>The scripted results do not require any connected hardware.</small><button onClick={() => this.setState({ failed: false })}>Retry 3D renderer</button></div> : this.props.children }
}

export default function SimulationScene(props: SceneProps) {
  return <SceneErrorBoundary><Canvas shadows={{ type: THREE.PCFShadowMap }} dpr={[1, 1.6]} camera={{ position: [4.6, 3.6, 7.6], fov: 37 }} gl={{ antialias: true, alpha: false, powerPreference: 'high-performance' }} onCreated={({ gl }) => { gl.toneMapping = THREE.ACESFilmicToneMapping; gl.toneMappingExposure = 1.1; props.onReady() }} aria-label="Interactive three-dimensional SPECTRA X concept demonstration"><Suspense fallback={null}><SceneContents {...props} /></Suspense></Canvas></SceneErrorBoundary>
}
