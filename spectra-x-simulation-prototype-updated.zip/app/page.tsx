import { Workspace } from '@/components/spectra/workspace'

export default function Page() {
  return <Workspace />
}
